﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.Sql;
using System.Data.SqlClient;

namespace ConnectServer
{
    public partial class Form1 : Form
    {
        string connectionString;
        SqlConnection connection;

        public Form1()
        {
            InitializeComponent();
            connectionString = ConfigurationManager.ConnectionStrings["ConnectServer.Properties.Settings.SampleConnectionString"].ConnectionString;
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            PopulateRecipes();
        }
        private void PopulateRecipes()
        {
            using (connection = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter("Select * from recipe", connection))
                {
                    connection.Open();
                    DataTable recipeTable = new DataTable();
                    adapter.Fill(recipeTable);
                    lstRecipe.DisplayMember = "Name";
                    lstRecipe.ValueMember = "Id";
                    lstRecipe.DataSource = recipeTable;

                    connection.Close();

                }
                  
            }
               
          
        }
    }
}
